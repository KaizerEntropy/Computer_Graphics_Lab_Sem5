#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QImage>
#include <QPainter>
#include <QFont>
#include <cmath>

// ---------------------------------------------------------------------
// Raster primitives
// ---------------------------------------------------------------------

static inline void setPixelSafe(QImage &img, int x, int y, const QColor &color)
{
    if (x >= 0 && x < img.width() && y >= 0 && y < img.height())
        img.setPixel(x, y, color.rgb());
}

static void drawLineBresenham(QImage &img, int x0, int y0, int x1, int y1, const QColor &color)
{
    int dx = std::abs(x1 - x0);
    int dy = -std::abs(y1 - y0);
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx + dy;
    while (true) {
        setPixelSafe(img, x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

static inline void fillRectPixels(QImage &img, int x, int y, int w, int h, const QColor &color)
{
    for (int yy = y; yy < y + h; ++yy)
        for (int xx = x; xx < x + w; ++xx)
            setPixelSafe(img, xx, yy, color);
}

static void drawGridLineBresenham(QImage &img, int c0, int r0, int c1, int r1,
                                   int gridSize, const QColor &color)
{
    int dc = std::abs(c1 - c0);
    int dr = -std::abs(r1 - r0);
    int sc = (c0 < c1) ? 1 : -1;
    int sr = (r0 < r1) ? 1 : -1;
    int err = dc + dr;
    while (true) {
        fillRectPixels(img, c0 * gridSize, r0 * gridSize, gridSize, gridSize, color);
        if (c0 == c1 && r0 == r1) break;
        int e2 = 2 * err;
        if (e2 >= dr) { err += dr; c0 += sc; }
        if (e2 <= dc) { err += dc; r0 += sr; }
    }
}

static void drawDashedGridLineBresenham(QImage &img, int c0, int r0, int c1, int r1,
                                         int gridSize, const QColor &color,
                                         int dashOn = 2, int dashOff = 1)
{
    int dc = std::abs(c1 - c0);
    int dr = -std::abs(r1 - r0);
    int sc = (c0 < c1) ? 1 : -1;
    int sr = (r0 < r1) ? 1 : -1;
    int err = dc + dr;
    int count = 0;
    while (true) {
        if ((count % (dashOn + dashOff)) < dashOn)
            fillRectPixels(img, c0 * gridSize, r0 * gridSize, gridSize, gridSize, color);
        if (c0 == c1 && r0 == r1) break;
        int e2 = 2 * err;
        if (e2 >= dr) { err += dr; c0 += sc; }
        if (e2 <= dc) { err += dc; r0 += sr; }
        ++count;
    }
}

// ---------------------------------------------------------------------
// Grid / axes
// ---------------------------------------------------------------------

static void drawAxesAndGrid(QImage &img, int width, int height, int gridSize)
{
    if (gridSize <= 0) gridSize = 1;
    int originX = (width / 2 / gridSize) * gridSize;
    int originY = (height / 2 / gridSize) * gridSize;

    for (int x = gridSize; x < width; x += gridSize)
        drawLineBresenham(img, x, 0, x, height - 1, Qt::red);
    for (int y = gridSize; y < height; y += gridSize)
        drawLineBresenham(img, 0, y, width - 1, y, Qt::red);

    QColor axisCell(50, 50, 50);
    for (int x = 0; x < width; x += gridSize)
        fillRectPixels(img, x, originY, gridSize, gridSize, axisCell);
    for (int y = 0; y < height; y += gridSize)
        fillRectPixels(img, originX, y, gridSize, gridSize, axisCell);

    fillRectPixels(img, originX, originY, gridSize, gridSize, Qt::white);
}

static int screenToCartesianFloor(int screenCoord, int originCoord, int gridSize)
{
    return static_cast<int>(std::floor(static_cast<double>(screenCoord - originCoord) / gridSize));
}

// ---------------------------------------------------------------------
// Cubic Bezier evaluation
// ---------------------------------------------------------------------

QPointF MainWindow::evalCubicBezier(const QPointF &P0, const QPointF &P1,
                                     const QPointF &P2, const QPointF &P3,
                                     double t)
{
    double u = 1.0 - t;
    double u2 = u * u;
    double u3 = u2 * u;
    double t2 = t * t;
    double t3 = t2 * t;

    double x = u3 * P0.x() + 3.0 * u2 * t * P1.x() + 3.0 * u * t2 * P2.x() + t3 * P3.x();
    double y = u3 * P0.y() + 3.0 * u2 * t * P1.y() + 3.0 * u * t2 * P2.y() + t3 * P3.y();
    return QPointF(x, y);
}

// ---------------------------------------------------------------------
// Constructor / destructor
// ---------------------------------------------------------------------

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->label_status->setWordWrap(true);
    ui->label_status->setText("Click 4 control points on the canvas,\nthen press \"Draw Bezier Curve\".");

    connect(ui->frame, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_Pressed()));
    connect(ui->frame, SIGNAL(sendMousePosition(QPoint&)), this, SLOT(showMousePosition(QPoint&)));

    redrawCanvas();
}

MainWindow::~MainWindow() { delete ui; }

// ---------------------------------------------------------------------
// Mouse tracking
// ---------------------------------------------------------------------

void MainWindow::showMousePosition(QPoint &pos)
{
    sc_x = pos.x();
    sc_y = pos.y();

    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) gridSize = 1;
    int width = ui->frame->width();
    int height = ui->frame->height();
    int originX = (width / 2 / gridSize) * gridSize;
    int originY = (height / 2 / gridSize) * gridSize;

    int cx = screenToCartesianFloor(sc_x, originX, gridSize);
    int cy = -screenToCartesianFloor(sc_y, originY, gridSize);

    ui->mouse_movement->setText("X : " + QString::number(cx) +
                                ", Y : " + QString::number(cy));
}

void MainWindow::Mouse_Pressed()
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) gridSize = 1;
    int width = ui->frame->width();
    int height = ui->frame->height();
    int originX = (width / 2 / gridSize) * gridSize;
    int originY = (height / 2 / gridSize) * gridSize;

    int lx = screenToCartesianFloor(sc_x, originX, gridSize);
    int ly = -screenToCartesianFloor(sc_y, originY, gridSize);

    controlPoints.append(QPointF(lx, ly));
    int n = controlPoints.size();
    int idx = n - 1;

    computeCurve();
    redrawCanvas();

    // First segment needs 4 pts, then every 2 more adds a segment
    int numSegments = (n >= 4) ? ((n - 4) / 2 + 1) : 0;
    bool segmentComplete = (n >= 4) && ((n - 4) % 2 == 0);

    if (n < 4) {
        ui->label_status->setText(QString("P%1 = (%2, %3)\nClick %4 more for first curve.")
                                       .arg(idx).arg(lx).arg(ly)
                                       .arg(4 - n));
    } else if (segmentComplete) {
        ui->label_status->setText(QString("Segment %1 complete! (%2 points total)\n"
                                          "Click 2 more to add next segment.")
                                       .arg(numSegments).arg(n));
    } else {
        ui->label_status->setText(QString("P%1 = (%2, %3)\nClick 1 more to complete next segment.")
                                       .arg(idx).arg(lx).arg(ly));
    }
}

// ---------------------------------------------------------------------
// Buttons
// ---------------------------------------------------------------------

void MainWindow::on_clear_clicked()
{
    controlPoints.clear();
    curvePoints.clear();
    curveDrawn = false;
    redrawCanvas();
    ui->label_status->setText("Canvas cleared.\nClick 4 control points on the canvas.");
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    if (arg1 <= 0) return;
    redrawCanvas();
}

void MainWindow::on_btn_draw_bezier_clicked()
{
    int n = controlPoints.size();
    if (n < 4) {
        ui->label_status->setText(QString("Need at least 4 points! You have %1.\nClick on canvas to add more.")
                                       .arg(n));
        return;
    }

    computeCurve();
    redrawCanvas();

    int numSegments = (n - 4) / 2 + 1;
    ui->label_status->setText(QString("Drawn %1 Bezier segment(s) using %2 points.")
                                   .arg(numSegments).arg(n));
}

// ---------------------------------------------------------------------
// Compute piecewise cubic Bezier with C1 continuity
// Segment 0: P0, P1, P2, P3  (user clicks 0..3)
// Segment k (k>=1): uses endpoint of prev segment, reflected point
//   for smooth tangent, then 2 new user-clicked points.
//   A = controlPoints[2k+1]       (shared endpoint)
//   B = 2*A - controlPoints[2k]   (reflection for C1)
//   C = controlPoints[2k+2]       (user click)
//   D = controlPoints[2k+3]       (user click)
// ---------------------------------------------------------------------

void MainWindow::computeCurve()
{
    int n = controlPoints.size();
    curvePoints.clear();
    curveDrawn = false;

    if (n < 4) return;

    int numSegments = (n - 4) / 2 + 1;
    const int numSteps = 200;

    for (int seg = 0; seg < numSegments; ++seg) {
        QPointF P0, P1, P2, P3;

        if (seg == 0) {
            P0 = controlPoints[0];
            P1 = controlPoints[1];
            P2 = controlPoints[2];
            P3 = controlPoints[3];
        } else {
            int base = seg * 2;
            // Shared endpoint from previous segment
            P0 = controlPoints[base + 1];
            // Reflected point: mirror controlPoints[base] across P0
            P1 = QPointF(2.0 * P0.x() - controlPoints[base].x(),
                         2.0 * P0.y() - controlPoints[base].y());
            // Two new user-clicked points
            P2 = controlPoints[base + 2];
            P3 = controlPoints[base + 3];
        }

        for (int i = 0; i <= numSteps; ++i) {
            double t = static_cast<double>(i) / numSteps;
            curvePoints.append(evalCubicBezier(P0, P1, P2, P3, t));
        }
    }
    curveDrawn = true;
}

// ---------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------

void MainWindow::redrawCanvas()
{
    int gridSize = ui->spinBox->value();
    if (gridSize <= 0) gridSize = 1;
    int width  = ui->frame->width();
    int height = ui->frame->height();

    QImage img(width, height, QImage::Format_RGB32);
    img.fill(Qt::black);
    drawAxesAndGrid(img, width, height, gridSize);

    int originX = (width  / 2 / gridSize) * gridSize;
    int originY = (height / 2 / gridSize) * gridSize;

    auto toCell = [&](const QPointF &p) -> QPoint {
        int sx = originX + static_cast<int>(std::round(p.x() * gridSize));
        int sy = originY - static_cast<int>(std::round(p.y() * gridSize));
        return QPoint(sx / gridSize, sy / gridSize);
    };

    // --- Draw Bezier curve (green, cell-by-cell using Bresenham between consecutive samples) ---
    if (curveDrawn && curvePoints.size() >= 2) {
        for (int i = 0; i < curvePoints.size() - 1; ++i) {
            QPoint c1 = toCell(curvePoints[i]);
            QPoint c2 = toCell(curvePoints[i + 1]);
            drawGridLineBresenham(img, c1.x(), c1.y(), c2.x(), c2.y(),
                                   gridSize, QColor(255, 105, 180));
        }
    }

    // --- Draw control points (red) and reflected points (cyan) with labels ---
    {
        QPainter painter(&img);
        painter.setFont(QFont("Arial", 10, QFont::Bold));

        // Draw user-clicked control points (red + white label)
        for (int i = 0; i < controlPoints.size(); ++i) {
            QPoint c = toCell(controlPoints[i]);
            fillRectPixels(img, c.x() * gridSize, c.y() * gridSize,
                           gridSize, gridSize, Qt::red);
            painter.setPen(Qt::white);
            painter.drawText(c.x() * gridSize + gridSize + 2,
                             c.y() * gridSize + gridSize / 2 + 4,
                             QString("P%1").arg(i));
        }

        // Draw auto-reflected points (cyan + yellow label)
        int n = controlPoints.size();
        int numSegments = (n >= 4) ? ((n - 4) / 2 + 1) : 0;
        for (int seg = 1; seg < numSegments; ++seg) {
            int base = seg * 2;
            QPointF endpoint = controlPoints[base + 1];
            QPointF reflected(2.0 * endpoint.x() - controlPoints[base].x(),
                              2.0 * endpoint.y() - controlPoints[base].y());
            QPoint c = toCell(reflected);
            fillRectPixels(img, c.x() * gridSize, c.y() * gridSize,
                           gridSize, gridSize, QColor(0, 255, 255));
            painter.setPen(Qt::yellow);
            painter.drawText(c.x() * gridSize + gridSize + 2,
                             c.y() * gridSize + gridSize / 2 + 4,
                             QString("R%1").arg(seg));
        }
    }

    ui->frame->setPixmap(QPixmap::fromImage(img));
}
