#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPoint>
#include <QPointF>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void showMousePosition(QPoint &pos);
    void Mouse_Pressed();

    void on_clear_clicked();
    void on_spinBox_valueChanged(int arg1);
    void on_btn_draw_bezier_clicked();

private:
    Ui::MainWindow *ui;

    void redrawCanvas();
    void computeCurve();

    int sc_x = 0;
    int sc_y = 0;

    // Control points for cubic Bezier (need exactly 4)
    QVector<QPointF> controlPoints;

    // Computed curve points
    QVector<QPointF> curvePoints;
    bool curveDrawn = false;

    // Evaluate cubic Bezier at parameter t
    static QPointF evalCubicBezier(const QPointF &P0, const QPointF &P1,
                                   const QPointF &P2, const QPointF &P3,
                                   double t);
};

#endif // MAINWINDOW_H
